package dt;

public class TruckException extends VehicleException {

    public TruckException(String parameter){
        super(parameter);
    }
}
